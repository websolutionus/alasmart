<?php
 return array (
  'Currencies' => 'Currencies',
  'Create Currency' => 'Create Currency',
  'Create currency' => 'Create Currency',
  'Currency' => 'Currency',
  'Country Code' => 'Country Code',
  'Currency Code' => 'Currency Code',
  'Before Price' => 'Before Price',
  'After Price' => 'After Price',
  'Edit Currency' => 'Edit Currency',

);
 ?>
