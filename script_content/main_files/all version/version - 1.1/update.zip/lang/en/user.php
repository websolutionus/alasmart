<?php
 return array (
  'USD Amount' => 'USD Amount',
);
 ?>
